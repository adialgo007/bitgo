package model;

public class Notification {
    int id;
    String coinName;
    Double price;
    int volume;
    double intraDayHigh;
    double getIntraDayLow;
    NotificationStatus notificationStatus;

    public Notification(String coinName, Double price, int volume, double intraDayHigh, double getIntraDayLow) {
        this.coinName = coinName;
        this.price = price;
        this.volume = volume;
        this.intraDayHigh = intraDayHigh;
        this.getIntraDayLow = getIntraDayLow;
    }

    public String getCoinName() {
        return coinName;
    }

    public void setCoinName(String coinName) {
        this.coinName = coinName;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        this.volume = volume;
    }

    public double getIntraDayHigh() {
        return intraDayHigh;
    }

    public void setIntraDayHigh(double intraDayHigh) {
        this.intraDayHigh = intraDayHigh;
    }

    public double getGetIntraDayLow() {
        return getIntraDayLow;
    }

    public void setGetIntraDayLow(double getIntraDayLow) {
        this.getIntraDayLow = getIntraDayLow;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public NotificationStatus getNotificationStatus() {
        return notificationStatus;
    }

    public void setNotificationStatus(NotificationStatus notificationStatus) {
        this.notificationStatus = notificationStatus;
    }
}
