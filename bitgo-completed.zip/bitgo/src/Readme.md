Improvements:

1. Using DTO instead of objects when calling and returning response from the API.
2. Using DB instead of in-memory hashmap.
3. Multi-concurrent support.