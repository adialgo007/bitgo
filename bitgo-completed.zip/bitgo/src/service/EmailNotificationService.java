package service;

import model.Notification;
import model.NotificationStatus;
import model.User;

public class EmailNotificationService implements NotificationChannelService{
    @Override
    public NotificationStatus sendNotification(Notification notification, User user) {
        if(user.getEmail() == null){
            return NotificationStatus.FAILED;
        }
        System.out.println("Sending email notification:" +  notification.getId() + " to: " + user.getEmail() );
        return NotificationStatus.SENT;
    }
}
