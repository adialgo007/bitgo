package service;

import dao.NotificationRepository;
import model.Channel;
import model.Notification;
import model.NotificationStatus;
import model.User;

import java.util.List;

public class NotificationService {

    NotificationRepository notificationRepository;

    public NotificationService(NotificationRepository notificationRepository) {
        this.notificationRepository = notificationRepository;
    }

    public void sendNotification(Notification notification, User user, Channel channel){
        notification.setNotificationStatus(NotificationStatus.OUTSTANDING);
        this.notificationRepository.addNotification(notification);
        NotificationChannelService notificationChannelService = NotificationChannelFactory.getChannel(channel);
        NotificationStatus notificationStatus = notificationChannelService.sendNotification(notification, user);
        notification.setNotificationStatus(notificationStatus);
    }

    public List<Notification> listNotifications(NotificationStatus notificationStatus){
        return this.notificationRepository.getNotificationsByStatus(notificationStatus);
    }

    public void deleteNotification(int notificationId){
        this.notificationRepository.deleteNotification(notificationId);
    }
}
