import dao.NotificationRepository;
import dao.NotificationRepositoryImpl;
import model.Channel;
import model.Notification;
import model.NotificationStatus;
import model.User;
import service.NotificationService;

import java.util.List;

public class Main {
    public static void main(String[] args) {

        /*
        Create a server which will be able to take in the following rest APIs

Create a notification. Line items may include current price of BTC, market trade volume, intra day high price, market cap
Send a notification to an email
List sent notifications (sent, outstanding, failed etc.)
Delete a notification
         */

        /*
        APIs

        POST API /notification
        sendNotification(Notification notification, User user, Channel channel)

        GET API /notification?status=sent
        GET API listNotifications(NotificationStatus notificationStatus)

        DELETE /notification/{notificationId}
        notification(int notificationId)

        POST API /archiveNotification
        archiveNotification(Date startTime, Date endTime)

          */


        NotificationRepository notificationRepository = new NotificationRepositoryImpl();
        NotificationService notificationService = new NotificationService(notificationRepository);

        // Create Users
        Notification notification1 = new Notification("BTC", 2.0, 100, 1.5, 2.5);
        Notification notification2 = new Notification("ETH", 2.0, 100, 1.5, 2.5);
        Notification notification3 = new Notification("BTC", 2.0, 100, 1.5, 2.5);

        // Create Notification
        User user1 = new User("user1", "email1.com");
        User user2 = new User("user1", "email2.com");
        User user3 = new User("user3");

        notificationService.sendNotification(notification1, user1, Channel.EMAIL);
        notificationService.sendNotification(notification2, user2, Channel.EMAIL);
        notificationService.sendNotification(notification3, user3, Channel.EMAIL);

        List<Notification> successNotifications = notificationService.listNotifications(NotificationStatus.SENT);
        System.out.println("printing success notifications");
        for(Notification notification: successNotifications){
            System.out.println(notification.getId());
        }
        List<Notification> failedNotifications = notificationService.listNotifications(NotificationStatus.FAILED);
        System.out.println("printing failed notifications");
        for(Notification notification: failedNotifications){
            System.out.println(notification.getId());
        }

        notificationService.deleteNotification(2);
        List<Notification> successNotifications2 = notificationService.listNotifications(NotificationStatus.SENT);
        System.out.println("printing success notifications after deleting notifcations");
        for(Notification notification: successNotifications2){
            System.out.println(notification.getId());
        }


    }
}