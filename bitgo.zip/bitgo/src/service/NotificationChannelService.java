package service;

import model.Notification;
import model.NotificationStatus;
import model.User;

public interface NotificationChannelService {
    NotificationStatus sendNotification(Notification notification, User user);
}
