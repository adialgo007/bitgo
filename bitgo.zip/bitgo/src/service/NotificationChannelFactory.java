package service;

import model.Channel;

public class NotificationChannelFactory {

    public static NotificationChannelService getChannel(Channel channel){
        if(channel == Channel.EMAIL){
            return new EmailNotificationService();
        } else {
            return  null;
        }
    }
}
