package model;

public enum NotificationStatus {
    SENT,
    OUTSTANDING,
    FAILED
}
