package model;

public enum Channel {
    EMAIL,
    SMS,
    PUSH
}
