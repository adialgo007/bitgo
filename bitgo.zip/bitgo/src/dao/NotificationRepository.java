package dao;

import model.Notification;
import model.NotificationStatus;

import java.util.List;

public interface NotificationRepository {
    void addNotification(Notification notification);
    void deleteNotification(int id);
    List<Notification> getAllNotifications();
    List<Notification> getNotificationsByStatus(NotificationStatus notificationStatus);
}
