package dao;

import model.Notification;
import model.NotificationStatus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NotificationRepositoryImpl implements NotificationRepository {

    Map<Integer, Notification> notificationMap;

    public NotificationRepositoryImpl() {
        this.notificationMap = new HashMap<>();
    }

    public Map<Integer, Notification> getNotificationMap() {
        return notificationMap;
    }

    public void setNotificationMap(Map<Integer, Notification> notificationMap) {
        this.notificationMap = notificationMap;
    }

    @Override
    public void addNotification(Notification notification) {
        int id = notificationMap.size();
        notification.setId(id + 1);
        notificationMap.put(notification.getId(), notification);
    }

    @Override
    public void deleteNotification(int id) {
        notificationMap.remove(id);
    }

    @Override
    public List<Notification> getAllNotifications() {
        return new ArrayList<>(notificationMap.values());
    }

    @Override
    public List<Notification> getNotificationsByStatus(NotificationStatus notificationStatus) {
        List<Notification> notifications = new ArrayList<>();
        for(Notification notification: notificationMap.values()){
            if(notification.getNotificationStatus() == notificationStatus){
                notifications.add(notification);
            }
        }
        return notifications;
    }
}
